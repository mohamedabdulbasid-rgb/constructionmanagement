# construction management

A Pen created on CodePen.

Original URL: [https://codepen.io/mohamedabdul-basid/pen/bNEEPjy](https://codepen.io/mohamedabdul-basid/pen/bNEEPjy).

